import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import DailyPreparationList from './components/teacher/DailyPreparationList';
import DailyPreparationForm from './components/teacher/DailyPreparationForm';
import AssignmentList from './components/teacher/AssignmentList';
import AssignmentForm from './components/teacher/AssignmentForm';
import AssignmentDetail from './components/teacher/AssignmentDetail';
import AttendanceForm from './components/teacher/AttendanceForm';
import StudentAssignmentList from './components/student/StudentAssignmentList';
import StudentAssignmentDetail from './components/student/StudentAssignmentDetail';
import StudentAttendanceRecord from './components/student/StudentAttendanceRecord';
import './App.css';

function App() {
  // Simple authentication check
  const isAuthenticated = () => {
    return localStorage.getItem('access_token') !== null;
  };

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={isAuthenticated() ? <Dashboard /> : <Navigate to="/login" />} />
          
          {/* Teacher Routes */}
          <Route path="/teacher/daily-preparations" element={isAuthenticated() && localStorage.getItem("user_role") === "teacher" ? <DailyPreparationList /> : <Navigate to="/login" />} />
          <Route path="/teacher/daily-preparations/new" element={isAuthenticated() && localStorage.getItem("user_role") === "teacher" ? <DailyPreparationForm /> : <Navigate to="/login" />} />
          <Route path="/teacher/daily-preparations/edit/:preparationId" element={isAuthenticated() && localStorage.getItem("user_role") === "teacher" ? <DailyPreparationForm isEditMode={true} /> : <Navigate to="/login" />} />
          <Route path="/teacher/assignments" element={isAuthenticated() && localStorage.getItem("user_role") === "teacher" ? <AssignmentList /> : <Navigate to="/login" />} />
          <Route path="/teacher/assignments/new" element={isAuthenticated() && localStorage.getItem("user_role") === "teacher" ? <AssignmentForm /> : <Navigate to="/login" />} />
          <Route path="/teacher/assignments/:assignmentId" element={isAuthenticated() && localStorage.getItem("user_role") === "teacher" ? <AssignmentDetail /> : <Navigate to="/login" />} />
          <Route path="/teacher/assignments/edit/:assignmentId" element={isAuthenticated() && localStorage.getItem("user_role") === "teacher" ? <AssignmentForm isEditMode={true} /> : <Navigate to="/login" />} />
          <Route path="/teacher/attendance" element={isAuthenticated() && localStorage.getItem("user_role") === "teacher" ? <AttendanceForm /> : <Navigate to="/login" />} />
          
          {/* Student Routes */}
          <Route path="/student/assignments" element={isAuthenticated() && localStorage.getItem("user_role") === "student" ? <StudentAssignmentList /> : <Navigate to="/login" />} />
          <Route path="/student/assignments/:assignmentId" element={isAuthenticated() && localStorage.getItem("user_role") === "student" ? <StudentAssignmentDetail /> : <Navigate to="/login" />} />
          <Route path="/student/attendance" element={isAuthenticated() && localStorage.getItem("user_role") === "student" ? <StudentAttendanceRecord /> : <Navigate to="/login" />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;

