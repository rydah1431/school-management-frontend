import { useState, useCallback } from 'react';
import { apiClient } from '../lib/apiClient';

export const useApi = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const request = useCallback(async (endpoint, options = {}) => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiClient.request(endpoint, options);
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const get = useCallback((endpoint) => request(endpoint, { method: 'GET' }), [request]);
  const post = useCallback((endpoint, data) => request(endpoint, { method: 'POST', body: JSON.stringify(data) }), [request]);
  const put = useCallback((endpoint, data) => request(endpoint, { method: 'PUT', body: JSON.stringify(data) }), [request]);
  const del = useCallback((endpoint) => request(endpoint, { method: 'DELETE' }), [request]);

  return { loading, error, get, post, put, delete: del, request };
};

