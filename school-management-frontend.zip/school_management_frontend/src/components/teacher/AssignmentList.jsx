import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const AssignmentList = () => {
  const [assignments, setAssignments] = useState([]);
  const [error, setError] = useState('');
  const teacherId = localStorage.getItem('user_id');

  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/assignments/teacher/${teacherId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch assignments');
        }
        const data = await response.json();
        setAssignments(data);
      } catch (err) {
        setError(err.message);
      }
    };
    fetchAssignments();
  }, [teacherId]);

  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد أنك تريد حذف هذا الواجب؟')) {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/assignments/${id}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to delete assignment');
        }
        setAssignments(assignments.filter(assignment => assignment.id !== id));
      } catch (err) {
        setError(err.message);
      }
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-2xl font-bold">الواجبات</CardTitle>
        <Link to="/teacher/assignments/new">
          <Button>إضافة واجب جديد</Button>
        </Link>
      </CardHeader>
      <CardContent>
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
        {assignments.length === 0 ? (
          <p>لا توجد واجبات حتى الآن.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>العنوان</TableHead>
                <TableHead>الفصل</TableHead>
                <TableHead>تاريخ الاستحقاق</TableHead>
                <TableHead>الوصف</TableHead>
                <TableHead className="text-right">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assignments.map((assignment) => (
                <TableRow key={assignment.id}>
                  <TableCell className="font-medium">{assignment.title}</TableCell>
                  <TableCell>{assignment.class_id}</TableCell>
                  <TableCell>{new Date(assignment.due_date).toLocaleDateString()}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{assignment.description}</TableCell>
                  <TableCell className="text-right">
                    <Link to={`/teacher/assignments/${assignment.id}`}>
                      <Button variant="outline" size="sm" className="mr-2">عرض</Button>
                    </Link>
                    <Link to={`/teacher/assignments/edit/${assignment.id}`}>
                      <Button variant="outline" size="sm" className="mr-2">تعديل</Button>
                    </Link>
                    <Button variant="destructive" size="sm" onClick={() => handleDelete(assignment.id)}>حذف</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default AssignmentList;

