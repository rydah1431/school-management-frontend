import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const AssignmentForm = ({ isEditMode = false }) => {
  const navigate = useNavigate();
  const { assignmentId } = useParams();
  const [classId, setClassId] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [classes, setClasses] = useState([]);

  const teacherId = localStorage.getItem('user_id');

  useEffect(() => {
    // Fetch classes for the teacher
    const fetchClasses = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/classes/teacher/${teacherId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch classes');
        }
        const data = await response.json();
        setClasses(data);
      } catch (err) {
        setError(err.message);
      }
    };
    fetchClasses();

    if (isEditMode && assignmentId) {
      const fetchAssignment = async () => {
        try {
          const token = localStorage.getItem('access_token');
          const response = await fetch(`/api/assignments/${assignmentId}`, {
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          });
          if (!response.ok) {
            throw new Error('Failed to fetch assignment');
          }
          const data = await response.json();
          setClassId(data.class_id);
          setTitle(data.title);
          setDescription(data.description);
          setDueDate(data.due_date);
          setAttachmentUrl(data.attachment_url || '');
        } catch (err) {
          setError(err.message);
        }
      };
      fetchAssignment();
    }
  }, [isEditMode, assignmentId, teacherId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const method = isEditMode ? 'PUT' : 'POST';
    const url = isEditMode ? `/api/assignments/${assignmentId}` : '/api/assignments';
    const body = {
      teacher_id: parseInt(teacherId),
      class_id: parseInt(classId),
      title,
      description,
      due_date: dueDate,
      attachment_url: attachmentUrl,
    };

    try {
      const token = localStorage.getItem('access_token');
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || `فشل ${isEditMode ? 'تحديث' : 'إنشاء'} الواجب`);
      }

      setSuccess(`تم ${isEditMode ? 'تحديث' : 'إنشاء'} الواجب بنجاح!`);
      navigate('/teacher/assignments');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>{isEditMode ? 'تعديل الواجب' : 'إنشاء واجب جديد'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="class">الفصل الدراسي</Label>
              <Select onValueChange={setClassId} value={classId} required>
                <SelectTrigger id="class">
                  <SelectValue placeholder="اختر فصل" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map(cls => (
                    <SelectItem key={cls.id} value={cls.id.toString()}>{cls.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="title">عنوان الواجب</Label>
              <Input
                id="title"
                placeholder="عنوان الواجب"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="description">وصف الواجب</Label>
            <Textarea
              id="description"
              placeholder="وصف تفصيلي للواجب..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="dueDate">تاريخ الاستحقاق</Label>
            <Input
              id="dueDate"
              type="datetime-local"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              required
            />
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="attachmentUrl">رابط المرفق (اختياري)</Label>
            <Input
              id="attachmentUrl"
              placeholder="رابط الملف أو المورد"
              value={attachmentUrl}
              onChange={(e) => setAttachmentUrl(e.target.value)}
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          {success && <p className="text-green-500 text-sm">{success}</p>}
          <CardFooter className="flex justify-end p-0 mt-4">
            <Button type="submit">{isEditMode ? 'تحديث الواجب' : 'إنشاء الواجب'}</Button>
          </CardFooter>
        </form>
      </CardContent>
    </Card>
  );
};

export default AssignmentForm;

