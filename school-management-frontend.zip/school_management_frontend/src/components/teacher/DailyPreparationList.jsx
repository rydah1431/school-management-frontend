import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const DailyPreparationList = () => {
  const [preparations, setPreparations] = useState([]);
  const [error, setError] = useState('');
  const teacherId = localStorage.getItem('user_id');

  useEffect(() => {
    const fetchPreparations = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/daily-preparations/teacher/${teacherId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch daily preparations');
        }
        const data = await response.json();
        setPreparations(data);
      } catch (err) {
        setError(err.message);
      }
    };
    fetchPreparations();
  }, [teacherId]);

  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد أنك تريد حذف هذا التحضير؟')) {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/daily-preparations/${id}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to delete daily preparation');
        }
        setPreparations(preparations.filter(prep => prep.id !== id));
      } catch (err) {
        setError(err.message);
      }
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-2xl font-bold">التحضير اليومي</CardTitle>
        <Link to="/teacher/daily-preparations/new">
          <Button>إضافة تحضير جديد</Button>
        </Link>
      </CardHeader>
      <CardContent>
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
        {preparations.length === 0 ? (
          <p>لا توجد تحضيرات يومية حتى الآن.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>التاريخ</TableHead>
                <TableHead>الفصل</TableHead>
                <TableHead>المادة</TableHead>
                <TableHead>الأهداف</TableHead>
                <TableHead className="text-right">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {preparations.map((prep) => (
                <TableRow key={prep.id}>
                  <TableCell>{new Date(prep.preparation_date).toLocaleDateString()}</TableCell>
                  <TableCell>{prep.class_id}</TableCell>
                  <TableCell>{prep.subject}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{prep.lesson_objectives}</TableCell>
                  <TableCell className="text-right">
                    <Link to={`/teacher/daily-preparations/edit/${prep.id}`}>
                      <Button variant="outline" size="sm" className="mr-2">تعديل</Button>
                    </Link>
                    <Button variant="destructive" size="sm" onClick={() => handleDelete(prep.id)}>حذف</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default DailyPreparationList;

