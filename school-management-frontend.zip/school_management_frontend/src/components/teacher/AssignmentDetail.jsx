import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const AssignmentDetail = () => {
  const { assignmentId } = useParams();
  const navigate = useNavigate();
  const [assignment, setAssignment] = useState(null);
  const [accessLog, setAccessLog] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchAssignmentDetail = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/assignments/${assignmentId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch assignment');
        }
        const data = await response.json();
        setAssignment(data);
      } catch (err) {
        setError(err.message);
      }
    };

    const fetchAccessLog = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/assignments/${assignmentId}/access-log`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch access log');
        }
        const data = await response.json();
        setAccessLog(data);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchAssignmentDetail();
    fetchAccessLog();
  }, [assignmentId]);

  if (!assignment) {
    return <div className="flex items-center justify-center min-h-screen">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{assignment.title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold">الوصف:</h3>
            <p>{assignment.description}</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold">تاريخ الاستحقاق:</h3>
              <p>{new Date(assignment.due_date).toLocaleDateString('ar-SA')}</p>
            </div>
            <div>
              <h3 className="font-semibold">الفصل:</h3>
              <p>{assignment.class_id}</p>
            </div>
          </div>
          {assignment.attachment_url && (
            <div>
              <h3 className="font-semibold">المرفق:</h3>
              <a href={assignment.attachment_url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                عرض المرفق
              </a>
            </div>
          )}
          <Button onClick={() => navigate('/teacher/assignments')}>العودة إلى قائمة الواجبات</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>الطلاب الذين دخلوا على الواجب</CardTitle>
        </CardHeader>
        <CardContent>
          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
          {accessLog.length === 0 ? (
            <p>لم يقم أي طالب بالدخول على هذا الواجب حتى الآن.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم الطالب</TableHead>
                  <TableHead>وقت الدخول</TableHead>
                  <TableHead>عدد مرات الدخول</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accessLog.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>{log.student_name}</TableCell>
                    <TableCell>{new Date(log.accessed_at).toLocaleString('ar-SA')}</TableCell>
                    <TableCell>{log.access_count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AssignmentDetail;

