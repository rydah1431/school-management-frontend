import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

const AttendanceForm = () => {
  const navigate = useNavigate();
  const [classId, setClassId] = useState('');
  const [attendanceDate, setAttendanceDate] = useState(new Date().toISOString().split('T')[0]);
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState({});
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [classes, setClasses] = useState([]);

  const teacherId = localStorage.getItem('user_id');

  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/classes/teacher/${teacherId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch classes');
        }
        const data = await response.json();
        setClasses(data);
      } catch (err) {
        setError(err.message);
      }
    };
    fetchClasses();
  }, [teacherId]);

  const handleClassChange = async (selectedClassId) => {
    setClassId(selectedClassId);
    try {
      const token = localStorage.getItem('access_token');
      const response = await fetch(`/api/classes/${selectedClassId}/students`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (!response.ok) {
        throw new Error('Failed to fetch students');
      }
      const data = await response.json();
      setStudents(data);
      // Initialize attendance state
      const initialAttendance = {};
      data.forEach(student => {
        initialAttendance[student.id] = true; // Default to present
      });
      setAttendance(initialAttendance);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleAttendanceChange = (studentId, isPresent) => {
    setAttendance({
      ...attendance,
      [studentId]: isPresent,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const attendanceRecords = Object.entries(attendance).map(([studentId, isPresent]) => ({
      student_id: parseInt(studentId),
      class_id: parseInt(classId),
      attendance_date: attendanceDate,
      is_present: isPresent,
    }));

    try {
      const token = localStorage.getItem('access_token');
      const response = await fetch('/api/attendance/bulk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(attendanceRecords),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'فشل تسجيل الحضور');
      }

      setSuccess('تم تسجيل الحضور بنجاح!');
      navigate('/teacher/attendance');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>تسجيل الحضور والغياب</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="class">الفصل الدراسي</Label>
              <Select onValueChange={handleClassChange} value={classId} required>
                <SelectTrigger id="class">
                  <SelectValue placeholder="اختر فصل" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map(cls => (
                    <SelectItem key={cls.id} value={cls.id.toString()}>{cls.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="date">التاريخ</Label>
              <input
                id="date"
                type="date"
                value={attendanceDate}
                onChange={(e) => setAttendanceDate(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                required
              />
            </div>
          </div>

          {classId && students.length > 0 && (
            <div className="border rounded-lg p-4">
              <h3 className="font-semibold mb-4">الطلاب</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {students.map((student) => (
                  <div key={student.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`student-${student.id}`}
                      checked={attendance[student.id] || false}
                      onCheckedChange={(checked) => handleAttendanceChange(student.id, checked)}
                    />
                    <Label htmlFor={`student-${student.id}`} className="font-normal cursor-pointer">
                      {student.full_name}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {error && <p className="text-red-500 text-sm">{error}</p>}
          {success && <p className="text-green-500 text-sm">{success}</p>}
          <CardFooter className="flex justify-end p-0 mt-4">
            <Button type="submit" disabled={!classId || students.length === 0}>تسجيل الحضور</Button>
          </CardFooter>
        </form>
      </CardContent>
    </Card>
  );
};

export default AttendanceForm;

