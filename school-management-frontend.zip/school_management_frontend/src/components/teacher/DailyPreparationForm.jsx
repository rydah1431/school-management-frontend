import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const DailyPreparationForm = ({ isEditMode = false }) => {
  const navigate = useNavigate();
  const { preparationId } = useParams();
  const [classId, setClassId] = useState('');
  const [subject, setSubject] = useState('');
  const [preparationDate, setPreparationDate] = useState('');
  const [lessonObjectives, setLessonObjectives] = useState('');
  const [lessonActivities, setLessonActivities] = useState('');
  const [resourcesUsed, setResourcesUsed] = useState('');
  const [assessmentMethods, setAssessmentMethods] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [classes, setClasses] = useState([]);

  const teacherId = localStorage.getItem('user_id');

  useEffect(() => {
    // Fetch classes for the teacher
    const fetchClasses = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/classes/teacher/${teacherId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch classes');
        }
        const data = await response.json();
        setClasses(data);
      } catch (err) {
        setError(err.message);
      }
    };
    fetchClasses();

    if (isEditMode && preparationId) {
      const fetchPreparation = async () => {
        try {
          const token = localStorage.getItem('access_token');
          const response = await fetch(`/api/daily-preparations/${preparationId}`, {
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          });
          if (!response.ok) {
            throw new Error('Failed to fetch daily preparation');
          }
          const data = await response.json();
          setClassId(data.class_id);
          setSubject(data.subject);
          setPreparationDate(data.preparation_date);
          setLessonObjectives(data.lesson_objectives);
          setLessonActivities(data.lesson_activities);
          setResourcesUsed(data.resources_used);
          setAssessmentMethods(data.assessment_methods);
          setNotes(data.notes);
        } catch (err) {
          setError(err.message);
        }
      };
      fetchPreparation();
    }
  }, [isEditMode, preparationId, teacherId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const method = isEditMode ? 'PUT' : 'POST';
    const url = isEditMode ? `/api/daily-preparations/${preparationId}` : '/api/daily-preparations';
    const body = {
      teacher_id: parseInt(teacherId),
      class_id: classId,
      subject,
      preparation_date: preparationDate,
      lesson_objectives: lessonObjectives,
      lesson_activities: lessonActivities,
      resources_used: resourcesUsed,
      assessment_methods: assessmentMethods,
      notes: notes,
    };

    try {
      const token = localStorage.getItem('access_token');
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || `فشل ${isEditMode ? 'تحديث' : 'إنشاء'} التحضير اليومي`);
      }

      setSuccess(`تم ${isEditMode ? 'تحديث' : 'إنشاء'} التحضير اليومي بنجاح!`);
      navigate('/teacher/daily-preparations');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>{isEditMode ? 'تعديل التحضير اليومي' : 'إنشاء تحضير يومي جديد'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="class">الفصل الدراسي</Label>
              <Select onValueChange={setClassId} value={classId} required>
                <SelectTrigger id="class">
                  <SelectValue placeholder="اختر فصل" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map(cls => (
                    <SelectItem key={cls.id} value={cls.id.toString()}>{cls.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="subject">المادة</Label>
              <Input
                id="subject"
                placeholder="مثال: الرياضيات"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
            </div>
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="preparationDate">تاريخ التحضير</Label>
            <Input
              id="preparationDate"
              type="date"
              value={preparationDate}
              onChange={(e) => setPreparationDate(e.target.value)}
              required
            />
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="lessonObjectives">أهداف الدرس</Label>
            <Textarea
              id="lessonObjectives"
              placeholder="أهداف الدرس..."
              value={lessonObjectives}
              onChange={(e) => setLessonObjectives(e.target.value)}
            />
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="lessonActivities">أنشطة الدرس</Label>
            <Textarea
              id="lessonActivities"
              placeholder="الأنشطة التي سيتم تنفيذها..."
              value={lessonActivities}
              onChange={(e) => setLessonActivities(e.target.value)}
            />
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="resourcesUsed">الموارد المستخدمة</Label>
            <Textarea
              id="resourcesUsed"
              placeholder="الكتب، الأدوات، إلخ..."
              value={resourcesUsed}
              onChange={(e) => setResourcesUsed(e.target.value)}
            />
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="assessmentMethods">طرق التقييم</Label>
            <Textarea
              id="assessmentMethods"
              placeholder="طرق تقييم الطلاب..."
              value={assessmentMethods}
              onChange={(e) => setAssessmentMethods(e.target.value)}
            />
          </div>
          <div className="flex flex-col space-y-1.5">
            <Label htmlFor="notes">ملاحظات</Label>
            <Textarea
              id="notes"
              placeholder="ملاحظات إضافية..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          {success && <p className="text-green-500 text-sm">{success}</p>}
          <CardFooter className="flex justify-end p-0 mt-4">
            <Button type="submit">{isEditMode ? 'تحديث التحضير' : 'إنشاء التحضير'}</Button>
          </CardFooter>
        </form>
      </CardContent>
    </Card>
  );
};

export default DailyPreparationForm;

