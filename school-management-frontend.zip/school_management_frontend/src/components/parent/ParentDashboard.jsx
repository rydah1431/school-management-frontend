import React from 'react';

const ParentDashboard = () => {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">لوحة تحكم ولي الأمر</h2>
      <p>مرحباً أيها ولي الأمر! هنا يمكنك متابعة أداء أبنائك وواجباتهم وحضورهم.</p>
      {/* Add parent-specific content here */}
    </div>
  );
};

export default ParentDashboard;

