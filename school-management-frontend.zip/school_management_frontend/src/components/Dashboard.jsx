import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminDashboard from './admin/AdminDashboard';
import TeacherDashboard from './teacher/TeacherDashboard';
import StudentDashboard from './student/StudentDashboard';
import ParentDashboard from './parent/ParentDashboard';

const Dashboard = () => {
  const navigate = useNavigate();
  const [userRole, setUserRole] = useState(null);
  const [username, setUsername] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('access_token');
    const role = localStorage.getItem('user_role');
    const storedUsername = localStorage.getItem('username');

    if (!token || !role) {
      navigate('/login');
    } else {
      setUserRole(role);
      setUsername(storedUsername);
    }
  }, [navigate]);

  if (!userRole) {
    return <div className="flex items-center justify-center min-h-screen">Loading Dashboard...</div>;
  }

  // Render specific dashboard based on user role
  switch (userRole) {
    case 'admin':
      return <AdminDashboard />;
    case 'teacher':
      return <TeacherDashboard />;
    case 'student':
      return <StudentDashboard />;
    case 'parent':
      return <ParentDashboard />;
    default:
      return (
        <div className="p-4">
          <h1 className="text-3xl font-bold mb-4">لوحة التحكم</h1>
          <p className="text-lg">مرحباً بك يا {username} ({userRole})!</p>
          <p className="text-red-500">دور غير معروف.</p>
        </div>
      );
  }
};

export default Dashboard;

