import React from 'react';

const AdminDashboard = () => {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">لوحة تحكم المدير</h2>
      <p>مرحباً أيها المدير! هنا يمكنك إدارة المستخدمين والفصول الدراسية.</p>
      {/* Add admin-specific content here */}
    </div>
  );
};

export default AdminDashboard;

