import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const navigate = useNavigate();
  const { logout, isAuthenticated, user } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  return (
    <nav className="bg-gray-800 p-4 text-white">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold">نظام إدارة المدرسة</Link>
        <div className="flex items-center">
          {isAuthenticated ? (
            <div className="flex items-center space-x-4">
              <span className="text-sm">{user?.full_name || user?.username}</span>
              <button onClick={handleLogout} className="hover:text-gray-300">تسجيل الخروج</button>
            </div>
          ) : (
            <>
              <Link to="/login" className="mr-4 hover:text-gray-300">تسجيل الدخول</Link>
              <Link to="/register" className="hover:text-gray-300">التسجيل</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

