import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const StudentDashboard = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">لوحة تحكم الطالب</h1>
        <p className="text-gray-600">مرحباً بك! عرض واجباتك وسجل حضورك</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">واجباتي</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">عرض جميع الواجبات المسندة إليك من المعلمين</p>
            <Link to="/student/assignments">
              <Button className="w-full">عرض الواجبات</Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">سجل الحضور</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">عرض سجل حضورك وغيابك</p>
            <Link to="/student/attendance">
              <Button className="w-full">عرض الحضور</Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>معلومات سريعة</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm">
            <li>✓ عرض جميع الواجبات المسندة إليك</li>
            <li>✓ معرفة مواعيد استحقاق الواجبات</li>
            <li>✓ تحميل المرفقات والموارد</li>
            <li>✓ متابعة سجل حضورك</li>
            <li>✓ عرض نسبة الحضور الخاصة بك</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentDashboard;

