import React, { useEffect, useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const StudentAttendanceRecord = () => {
  const [attendance, setAttendance] = useState([]);
  const [error, setError] = useState('');
  const [stats, setStats] = useState({ total: 0, present: 0, absent: 0, percentage: 0 });
  const studentId = localStorage.getItem('user_id');

  useEffect(() => {
    const fetchAttendance = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/attendance/student/${studentId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch attendance');
        }
        const data = await response.json();
        setAttendance(data);

        // Calculate statistics
        const total = data.length;
        const present = data.filter(record => record.is_present).length;
        const absent = total - present;
        const percentage = total > 0 ? ((present / total) * 100).toFixed(2) : 0;

        setStats({ total, present, absent, percentage });
      } catch (err) {
        setError(err.message);
      }
    };
    fetchAttendance();
  }, [studentId]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-gray-600">إجمالي الأيام</p>
              <p className="text-3xl font-bold">{stats.total}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-gray-600">الحضور</p>
              <p className="text-3xl font-bold text-green-600">{stats.present}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-gray-600">الغياب</p>
              <p className="text-3xl font-bold text-red-600">{stats.absent}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-gray-600">نسبة الحضور</p>
              <p className="text-3xl font-bold text-blue-600">{stats.percentage}%</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>سجل الحضور</CardTitle>
        </CardHeader>
        <CardContent>
          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
          {attendance.length === 0 ? (
            <p>لا توجد سجلات حضور حتى الآن.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>التاريخ</TableHead>
                  <TableHead>الفصل</TableHead>
                  <TableHead>الحالة</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attendance.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell>{new Date(record.attendance_date).toLocaleDateString('ar-SA')}</TableCell>
                    <TableCell>{record.class_id}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded text-sm font-semibold ${
                        record.is_present 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {record.is_present ? 'حاضر' : 'غائب'}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentAttendanceRecord;

