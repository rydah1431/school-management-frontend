import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const StudentAssignmentDetail = () => {
  const { assignmentId } = useParams();
  const navigate = useNavigate();
  const [assignment, setAssignment] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchAssignmentDetail = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/assignments/${assignmentId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch assignment');
        }
        const data = await response.json();
        setAssignment(data);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchAssignmentDetail();
  }, [assignmentId]);

  if (!assignment) {
    return <div className="flex items-center justify-center min-h-screen">جاري التحميل...</div>;
  }

  const isOverdue = new Date(assignment.due_date) < new Date();

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{assignment.title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold">الوصف:</h3>
            <p className="mt-2 whitespace-pre-wrap">{assignment.description}</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold">تاريخ الاستحقاق:</h3>
              <p className={isOverdue ? 'text-red-600 font-semibold' : ''}>
                {new Date(assignment.due_date).toLocaleDateString('ar-SA')} {new Date(assignment.due_date).toLocaleTimeString('ar-SA')}
              </p>
            </div>
            <div>
              <h3 className="font-semibold">الحالة:</h3>
              <p className={`font-semibold ${isOverdue ? 'text-red-600' : 'text-green-600'}`}>
                {isOverdue ? 'منتهية الصلاحية' : 'نشطة'}
              </p>
            </div>
          </div>
          {assignment.attachment_url && (
            <div>
              <h3 className="font-semibold">المرفق:</h3>
              <a href={assignment.attachment_url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                تحميل المرفق
              </a>
            </div>
          )}
          <Button onClick={() => navigate('/student/assignments')}>العودة إلى الواجبات</Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default StudentAssignmentDetail;

