import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const StudentAssignmentList = () => {
  const [assignments, setAssignments] = useState([]);
  const [error, setError] = useState('');
  const studentId = localStorage.getItem('user_id');

  useEffect(() => {
    const fetchAssignments = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`/api/assignments/student/${studentId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch assignments');
        }
        const data = await response.json();
        setAssignments(data);
      } catch (err) {
        setError(err.message);
      }
    };
    fetchAssignments();
  }, [studentId]);

  const handleAssignmentClick = async (assignmentId) => {
    try {
      const token = localStorage.getItem('access_token');
      await fetch(`/api/assignments/${assignmentId}/access-log`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
    } catch (err) {
      console.error('Failed to log access:', err);
    }
  };

  const isOverdue = (dueDate) => {
    return new Date(dueDate) < new Date();
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl font-bold">واجباتي</CardTitle>
      </CardHeader>
      <CardContent>
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
        {assignments.length === 0 ? (
          <p>لا توجد واجبات حالياً.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>العنوان</TableHead>
                <TableHead>المادة</TableHead>
                <TableHead>تاريخ الاستحقاق</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead className="text-right">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assignments.map((assignment) => (
                <TableRow key={assignment.id} className={isOverdue(assignment.due_date) ? 'bg-red-50' : ''}>
                  <TableCell className="font-medium">{assignment.title}</TableCell>
                  <TableCell>{assignment.subject || 'عام'}</TableCell>
                  <TableCell>{new Date(assignment.due_date).toLocaleDateString('ar-SA')}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded text-sm ${
                      isOverdue(assignment.due_date) 
                        ? 'bg-red-100 text-red-800' 
                        : 'bg-green-100 text-green-800'
                    }`}>
                      {isOverdue(assignment.due_date) ? 'منتهية الصلاحية' : 'نشطة'}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Link to={`/student/assignments/${assignment.id}`} onClick={() => handleAssignmentClick(assignment.id)}>
                      <Button variant="outline" size="sm">عرض</Button>
                    </Link>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default StudentAssignmentList;

